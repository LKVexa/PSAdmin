<#
  Adds a right-click entry on .ps1 files:  "Run as Administrator (PS-Admin)"

  Per-user only - writes under HKCU:\Software\Classes. No admin rights needed,
  nothing outside your own profile is touched, and Uninstall-ContextMenu.ps1
  removes it completely.

  Run with -WhatIf to see exactly what it would write.
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param([switch]$Quiet)

$ErrorActionPreference = 'Stop'
$launcher = Join-Path $PSScriptRoot 'PS-Admin.cmd'
if (-not (Test-Path -LiteralPath $launcher)) { throw "PS-Admin.cmd is not beside this script." }

$key    = 'HKCU:\Software\Classes\Microsoft.PowerShellScript.1\shell\PSAdminRunAs'
$cmdKey = Join-Path $key 'command'
$cmd    = ('"{0}" "%1"' -f $launcher)

if ($PSCmdlet.ShouldProcess($key, 'create right-click entry for .ps1')) {
    New-Item -Path $key -Force | Out-Null
    New-ItemProperty -Path $key -Name '(default)' -Value 'Run as Administrator (PS-Admin)' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name 'Icon' -Value 'powershell.exe,0' -PropertyType String -Force | Out-Null
    New-Item -Path $cmdKey -Force | Out-Null
    New-ItemProperty -Path $cmdKey -Name '(default)' -Value $cmd -PropertyType String -Force | Out-Null

    if (-not $Quiet) {
        Write-Host ''
        Write-Host '  Added to the .ps1 right-click menu:' -ForegroundColor Green
        Write-Host '    Run as Administrator (PS-Admin)' -ForegroundColor White
        Write-Host ''
        Write-Host ('  registry  {0}' -f $key) -ForegroundColor DarkGray
        Write-Host ('  runs      {0}' -f $cmd) -ForegroundColor DarkGray
        Write-Host ''
        Write-Host '  On Windows 11 it may sit under "Show more options".' -ForegroundColor DarkGray
        Write-Host '  Undo any time with Uninstall-ContextMenu.ps1' -ForegroundColor DarkGray
    }
}
