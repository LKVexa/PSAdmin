<#
  PSAdmin.ps1 - open an Administrator PowerShell for a .ps1 script, and only
  for a .ps1 script.

  Drag a .ps1 onto PS-Admin.cmd, or double-click PS-Admin.cmd and pick one.
  Anything that is not a PowerShell script is refused.

    PSAdmin.ps1 -Script C:\path\to\thing.ps1
    PSAdmin.ps1 -Script x.ps1 -Force          # skip the confirmation
    PSAdmin.ps1 -Script x.ps1 -Arguments '-Mode quick'
    PSAdmin.ps1 -Task selftest
#>
[CmdletBinding()]
param(
    [string]$Script    = '',
    [string]$Arguments = '',
    [switch]$Force,
    [switch]$NoExit    = $true,
    [string]$Task      = 'run'
)

$ErrorActionPreference = 'Stop'

# Only these are ever accepted. The whole point of the tool.
$script:AllowedExt = @('.ps1')

function Say  { param([string]$T = '', [string]$C = 'Gray') Write-Host $T -ForegroundColor $C }
function Head { param([string]$T) Say ''; Say $T 'Cyan'; Say ('-' * [Math]::Min(76, [Math]::Max(6, $T.Length))) 'DarkCyan' }

function Test-Elevated {
    # sudo (MIT) checks TOKEN_ELEVATION on the process token; the .NET
    # WindowsPrincipal role check is the managed equivalent.
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-PickedScript {
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Title  = 'Pick a PowerShell script to run as Administrator'
        $dlg.Filter = 'PowerShell scripts (*.ps1)|*.ps1'   # the picker enforces it too
        $dlg.Multiselect = $false
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.FileName }
    } catch {
        Say ("  Could not open a file picker: {0}" -f $_.Exception.Message) 'Yellow'
    }
    return ''
}

# Returns a validated full path, or $null with the reason printed.
function Resolve-ScriptPath {
    param([string]$Path)

    if (-not $Path) { Say '  No script given.' 'Red'; return $null }
    $Path = $Path.Trim().Trim('"')

    if (-not (Test-Path -LiteralPath $Path)) {
        Say ("  Not found: {0}" -f $Path) 'Red'; return $null
    }
    $item = Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
    if (-not $item) { Say ("  Cannot read: {0}" -f $Path) 'Red'; return $null }

    if ($item.PSIsContainer) {
        Say ("  That is a folder, not a script: {0}" -f $item.FullName) 'Red'; return $null
    }

    $ext = $item.Extension.ToLower()
    if ($script:AllowedExt -notcontains $ext) {
        Say ''
        Say ("  REFUSED: '{0}' is a {1} file." -f $item.Name, $ext) 'Red'
        Say  "  This tool elevates PowerShell scripts (.ps1) and nothing else." 'Yellow'
        Say  "  It will not run .cmd, .bat, .exe, .vbs, .msi or anything else." 'DarkGray'
        return $null
    }
    return $item
}

function Get-RiskNotes {
    param([string]$Path)
    $notes = @()
    $text = ''
    try { $text = [System.IO.File]::ReadAllText($Path) } catch { return @('could not read the file to inspect it') }
    $patterns = @{
        'formats or wipes a volume'      = 'Format-Volume|Clear-Disk|diskpart|Initialize-Disk|Remove-Partition'
        'deletes recursively'            = 'Remove-Item[^\r\n]*-Recurse|rd /s|rmdir /s|robocopy[^\r\n]*/MIR'
        'changes execution policy'       = 'Set-ExecutionPolicy'
        'writes to the registry'         = 'New-ItemProperty|Set-ItemProperty|reg add|reg delete|Remove-ItemProperty'
        'changes services or scheduled tasks' = 'Set-Service|Stop-Service|New-Service|Register-ScheduledTask|schtasks'
        'downloads from the internet'    = 'Invoke-WebRequest|Invoke-RestMethod|curl |wget |DownloadString|DownloadFile'
        'creates or changes user accounts' = 'New-LocalUser|Add-LocalGroupMember|net user|net localgroup'
    }
    foreach ($k in $patterns.Keys) {
        if ($text -match $patterns[$k]) { $notes += $k }
    }
    return $notes
}

function Show-Preview {
    param($Item, [string]$Args)
    Head 'ABOUT TO RUN AS ADMINISTRATOR'
    Say ("  script     {0}" -f $Item.Name) 'White'
    Say ("  folder     {0}" -f $Item.DirectoryName)
    Say ("  size       {0:N0} bytes" -f $Item.Length)
    Say ("  modified   {0}" -f $Item.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))
    if ($Args) { Say ("  arguments  {0}" -f $Args) }

    $sig = $null
    try { $sig = Get-AuthenticodeSignature -LiteralPath $Item.FullName -ErrorAction SilentlyContinue } catch {}
    if ($sig -and $sig.Status -eq 'Valid') {
        Say ("  signature  signed by {0}" -f $sig.SignerCertificate.Subject) 'Green'
    } else {
        Say  "  signature  unsigned (normal for your own scripts)" 'DarkGray'
    }

    $risks = Get-RiskNotes -Path $Item.FullName
    if ($risks.Count -gt 0) {
        Say ''
        Say  "  This script contains code that:" 'Yellow'
        foreach ($r in $risks) { Say ("    - {0}" -f $r) 'Yellow' }
        Say  "  Running it as administrator removes the usual protections." 'Yellow'
    }
}

function Invoke-Elevated {
    param($Item, [string]$Args)

    $dir = $Item.DirectoryName
    $ps1 = $Item.FullName

    # PowerShell single-quote escaping: double any embedded quote.
    $qDir = $dir -replace "'", "''"
    $qPs1 = $ps1 -replace "'", "''"

    # ---------------------------------------------------------------------
    # The CWD trap, straight from sudo (MIT), sudo/src/run_handler.rs:
    #   "ShellExecuteEx will always set the CWD to system32, if the target exe
    #    is in the Windows dir. It does this _deep_ in the OS and there's
    #    nothing we can do to avoid it."
    # powershell.exe lives in C:\Windows\System32\WindowsPowerShell\v1.0, so
    # -Verb RunAs lands the elevated session in System32 and Start-Process
    # -WorkingDirectory is silently ignored. Any relative path in the script
    # would then resolve against System32. So set the location INSIDE the new
    # session rather than trying to set it from outside.
    # ---------------------------------------------------------------------
    $inner = "Set-Location -LiteralPath '$qDir'; & '$qPs1'"
    if ($Args) { $inner += " $Args" }
    $inner += "; Write-Host ''; Write-Host ('[PS-Admin] exit code: ' + `$LASTEXITCODE) -ForegroundColor DarkGray"

    $psArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass')
    if ($NoExit) { $psArgs += '-NoExit' }
    $psArgs += @('-Command', $inner)

    if (Test-Elevated) {
        # sudo's pattern: already elevated, so skip ShellExecute entirely.
        Say ''
        Say  '  Already running as administrator - running it here.' 'Green'
        Say ''
        Set-Location -LiteralPath $dir
        & $ps1
        Say ''
        Say ("  [PS-Admin] exit code: {0}" -f $LASTEXITCODE) 'DarkGray'
        return 0
    }

    Say ''
    Say  '  Asking Windows for administrator rights - approve the UAC prompt.' 'Yellow'
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $psArgs | Out-Null
    } catch {
        Say ''
        Say  '  Elevation was declined or failed.' 'Red'
        Say ("  {0}" -f $_.Exception.Message) 'DarkGray'
        return 1
    }
    Say  '  An administrator window has opened with your script.' 'Green'
    return 0
}

# ---------------------------------------------------------------- self test
function Invoke-SelfTest {
    Head 'PS-ADMIN SELF TEST  (elevates nothing)'
    $fails = 0
    $tmp = Join-Path $env:TEMP ('psadmin_t_' + [Guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Force -Path $tmp | Out-Null

    $good = Join-Path $tmp 'ok script.ps1'          # space in the name on purpose
    Set-Content -LiteralPath $good -Value "Write-Host 'hello'" -Encoding ASCII
    $bad  = Join-Path $tmp 'thing.cmd'
    Set-Content -LiteralPath $bad -Value "@echo off" -Encoding ASCII
    $risky = Join-Path $tmp 'risky.ps1'
    Set-Content -LiteralPath $risky -Value "Format-Volume -DriveLetter Z`nRemove-Item C:\x -Recurse" -Encoding ASCII

    Say '  a .ps1 is accepted' 'DarkGray'
    $r = Resolve-ScriptPath -Path $good
    if ($r) { Say '  ok   .ps1 accepted (name contains a space)' 'Green' } else { $fails++; Say '  FAIL .ps1 was not accepted' 'Red' }

    Say ''
    Say '  a .cmd is refused' 'DarkGray'
    $r = Resolve-ScriptPath -Path $bad
    if ($r) { $fails++; Say '  FAIL .cmd was NOT refused' 'Red' } else { Say '  ok   .cmd refused' 'Green' }

    Say ''
    Say '  a folder is refused' 'DarkGray'
    $r = Resolve-ScriptPath -Path $tmp
    if ($r) { $fails++; Say '  FAIL folder was NOT refused' 'Red' } else { Say '  ok   folder refused' 'Green' }

    Say ''
    Say '  a missing file is refused' 'DarkGray'
    $r = Resolve-ScriptPath -Path (Join-Path $tmp 'nope.ps1')
    if ($r) { $fails++; Say '  FAIL missing file was NOT refused' 'Red' } else { Say '  ok   missing file refused' 'Green' }

    Say ''
    Say '  risky cmdlets are noticed' 'DarkGray'
    $notes = Get-RiskNotes -Path $risky
    if ($notes.Count -ge 2) { Say ("  ok   flagged: {0}" -f ($notes -join '; ')) 'Green' }
    else { $fails++; Say ("  FAIL expected 2+ risk notes, got {0}" -f $notes.Count) 'Red' }

    Say ''
    Say '  quote escaping for awkward paths' 'DarkGray'
    $weird = "C:\it's a folder\x.ps1"
    $esc = $weird -replace "'", "''"
    if ($esc -eq "C:\it''s a folder\x.ps1") { Say '  ok   single quotes doubled' 'Green' }
    else { $fails++; Say ("  FAIL escaping produced: {0}" -f $esc) 'Red' }

    Say ''
    Say ("  elevation right now: {0}" -f $(if (Test-Elevated) { 'administrator' } else { 'standard user' })) 'DarkGray'

    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Say ''
    if ($fails -eq 0) { Say '  ALL CHECKS PASSED' 'Green' } else { Say ("  {0} CHECK(S) FAILED" -f $fails) 'Red' }
    return $fails
}

# ----------------------------------------------------------------- dispatch
function Invoke-Run {
    Head 'PS-ADMIN'
    Say  '  Runs a PowerShell script as administrator. .ps1 only.' 'DarkGray'

    $path = $Script
    if (-not $path) {
        Say ''
        Say '  No script given - opening a picker.' 'DarkGray'
        $path = Get-PickedScript
        if (-not $path) { Say '  Nothing chosen.' 'Green'; return 0 }
    }

    $item = Resolve-ScriptPath -Path $path
    if (-not $item) { return 2 }

    Show-Preview -Item $item -Args $Arguments

    if (-not $Force) {
        Say ''
        $a = Read-Host '  Press Enter to run it as administrator, or type n to cancel'
        if ($a -and $a.Trim().ToLower().StartsWith('n')) {
            Say '  Cancelled. Nothing was run.' 'Green'
            return 0
        }
    }
    return (Invoke-Elevated -Item $item -Args $Arguments)
}

function Get-ExitCode { param($v)
    $last = @($v) | Select-Object -Last 1
    $n = 0
    if ([int]::TryParse([string]$last, [ref]$n)) { return $n }
    return 0
}

switch ($Task.ToLower()) {
    'selftest' { exit (Get-ExitCode (Invoke-SelfTest)) }
    'run'      { exit (Get-ExitCode (Invoke-Run)) }
    default    { Say ("Unknown task '{0}'" -f $Task) 'Red'; exit 1 }
}
