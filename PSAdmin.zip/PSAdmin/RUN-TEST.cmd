@echo off
cd /d "%~dp0"
set LOG=%~dp0test-out.log
echo === 1 parse (all scripts) === > "%LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ParseAll.ps1" >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo === 2 selftest === >> "%LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PSAdmin.ps1" -Task selftest >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo === 3 refuse a .cmd via the normal path === >> "%LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PSAdmin.ps1" -Script "%~dp0PS-Admin.cmd" -Force >> "%LOG%" 2>&1
echo exitcode=%errorlevel% >> "%LOG%"
echo. >> "%LOG%"
echo === 4 context menu -WhatIf (writes nothing) === >> "%LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0Install-ContextMenu.ps1' -WhatIf" >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo === 5 confirm nothing was written === >> "%LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path 'HKCU:\Software\Classes\Microsoft.PowerShellScript.1\shell\PSAdminRunAs') { 'REGISTRY KEY EXISTS - WhatIf leaked' } else { 'ok  registry untouched by -WhatIf' }" >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo ALLDONE >> "%LOG%"
