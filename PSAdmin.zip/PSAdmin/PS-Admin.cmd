@echo off
setlocal
cd /d "%~dp0"
title PS-Admin
if "%~1"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PSAdmin.ps1"
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PSAdmin.ps1" -Script "%~1"
)
if errorlevel 2 pause
