<# Removes the "Run as Administrator (PS-Admin)" entry from .ps1 files. #>
[CmdletBinding(SupportsShouldProcess = $true)]
param()
$ErrorActionPreference = 'Stop'
$key = 'HKCU:\Software\Classes\Microsoft.PowerShellScript.1\shell\PSAdminRunAs'
if (Test-Path -LiteralPath $key) {
    if ($PSCmdlet.ShouldProcess($key, 'remove right-click entry')) {
        Remove-Item -LiteralPath $key -Recurse -Force
        Write-Host ''
        Write-Host '  Removed. The .ps1 right-click menu is back to normal.' -ForegroundColor Green
    }
} else {
    Write-Host ''
    Write-Host '  Nothing to remove - the entry is not installed.' -ForegroundColor Green
}
