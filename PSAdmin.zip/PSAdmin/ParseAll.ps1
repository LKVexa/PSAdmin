$ok = $true
foreach ($f in @('PSAdmin.ps1','Install-ContextMenu.ps1','Uninstall-ContextMenu.ps1')) {
    $p = Join-Path $PSScriptRoot $f
    if (-not (Test-Path -LiteralPath $p)) { Write-Host "MISSING $f"; $ok=$false; continue }
    $errs = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($p, [ref]$null, [ref]$errs)
    if ($errs -and $errs.Count) { $ok=$false; foreach($e in $errs){ Write-Host ("PARSE ERROR {0} line {1}: {2}" -f $f,$e.Extent.StartLineNumber,$e.Message) } }
    else { Write-Host ("parse ok  {0}" -f $f) }
}
if (-not $ok) { exit 1 }
Write-Host 'PARSE OK'
