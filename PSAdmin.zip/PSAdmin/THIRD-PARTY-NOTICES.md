# Third-party notices - PS-Admin

## Sudo for Windows

- **Donor repo (yard):** `sudo` - Sudo for Windows
  (`C:\Users\russe\OneDrive\Desktop\GitHub Junkyard\sudo`, working-tree clone)
- **Parts used:** `sudo/src/run_handler.rs`, `sudo/src/helpers.rs`
- **Licence:** MIT (`donor-parts/sudo/LICENSE`)
- **Originals kept at:** `donor-parts/sudo/sudo/src/`

No code was copied verbatim - sudo is Rust and PS-Admin is PowerShell. What was
pulled is its **design and its documented OS behaviour**:

1. **The elevation mechanism.** `runas_admin_impl` in `run_handler.rs` calls
   `ShellExecuteExW` with `lpVerb: w!("runas")`. `Start-Process -Verb RunAs`
   is the managed wrapper over the same call, and is what PS-Admin uses.

2. **The System32 working-directory trap** - the most valuable part. From
   `run_handler.rs`:

   > `ShellExecuteEx` will always set the CWD to system32, if the target exe
   > is in the Windows dir. It does this _deep_ in the OS and there's nothing
   > we can do to avoid it.

   `powershell.exe` lives in `C:\Windows\System32\WindowsPowerShell\v1.0\`, so
   an elevated PowerShell started this way begins in **System32**, and
   `Start-Process -WorkingDirectory` is silently ignored. Every relative path
   in the elevated script would resolve against System32. PS-Admin therefore
   issues `Set-Location` *inside* the new session instead of trying to set the
   directory from outside. Without this donor note the bug would have shipped,
   and it fails quietly rather than loudly.

3. **Skip elevation when already elevated.** `do_request` checks
   `is_running_elevated()` and spawns the target directly rather than doing
   "a whole bunch of ShellExecute". PS-Admin does the same via
   `WindowsPrincipal.IsInRole`, which is the managed equivalent of the
   `TOKEN_ELEVATION` check in `helpers.rs`.

4. **Quoting.** `join_args` in `helpers.rs` quotes an argument when it is empty
   or contains a space or tab. PS-Admin's need is narrower - it builds one
   `-Command` string using single quotes and doubles any embedded single quote -
   but the concern came from reading that function.

Sudo itself flags the gap this tool fills, in `run_handler.rs`:

> `TODO: figure out how to handle non-exe files. ShellExecute(runas, ...`

```
Copyright (c) Microsoft Corporation. All rights reserved.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Built new

The .ps1-only gate, the file picker, the pre-flight preview (size, modified,
Authenticode status, risky-cmdlet scan) and the optional right-click context
menu are original. Searched the yard for: elevation uac administrator privilege
runas; script launcher shell context menu registry; powershell host runspace
execute script; windows shell extension file association verb.
