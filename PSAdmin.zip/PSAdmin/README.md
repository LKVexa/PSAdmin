# PS-Admin

Opens an **Administrator PowerShell** for a script — and only for a
**PowerShell script**. Anything that is not a `.ps1` is refused.

## Three ways to use it

1. **Drag a `.ps1` onto `PS-Admin.cmd`.**
2. **Double-click `PS-Admin.cmd`** with nothing selected — a file picker opens,
   filtered to `*.ps1`.
3. **Right-click any `.ps1` → "Run as Administrator (PS-Admin)"** — after you
   run `Add-RightClick-Menu.cmd` once. See below.

Each way shows you what it is about to run, then asks for UAC.

## What you see before anything runs

```
ABOUT TO RUN AS ADMINISTRATOR
-----------------------------
  script     DWipe-Elevate.ps1
  folder     C:\...\_YARDOFFICE\DWipe
  size       7,412 bytes
  modified   2026-09-03 22:40
  signature  unsigned (normal for your own scripts)

  This script contains code that:
    - formats or wipes a volume
    - deletes recursively
  Running it as administrator removes the usual protections.

  Press Enter to run it as administrator, or type n to cancel
```

The risk lines come from scanning the script for things worth a second look —
volume formatting, recursive deletes, execution-policy changes, registry
writes, service and scheduled-task changes, downloads, and account changes.
It is a prompt to read, not a verdict. Pass `-Force` to skip the pause.

## Why it refuses everything except .ps1

That is the whole point of the tool. A general "run this as admin" launcher
will happily elevate a `.exe` or a `.bat` you did not look at. This one takes
PowerShell scripts, which are plain text you can read first — and it shows you
the file's details before the UAC prompt.

```
REFUSED: 'setup.exe' is a .exe file.
This tool elevates PowerShell scripts (.ps1) and nothing else.
```

Folders, missing files and non-`.ps1` files are all refused, and the file
picker is filtered so you cannot pick the wrong kind by accident.

## The bug this tool exists to avoid

`Start-Process -Verb RunAs` goes through `ShellExecuteEx`, and
**`ShellExecuteEx` forces the working directory to `System32` whenever the
target executable lives in the Windows directory.** `powershell.exe` does
(`C:\Windows\System32\WindowsPowerShell\v1.0\`), so an elevated PowerShell
started the obvious way begins in `System32` — and `-WorkingDirectory` is
silently ignored, because the OS overrides it deep inside.

Any relative path in your script then resolves against `System32`. A script
that writes `.\output.csv` writes it to a system folder; one that reads
`.\config.json` fails to find it. Nothing errors loudly.

PS-Admin therefore runs `Set-Location` **inside** the new elevated session
rather than trying to set the directory from outside, so your script starts in
its own folder like it would if you ran it normally.

That behaviour is documented in Sudo for Windows, which is where it came from —
see `THIRD-PARTY-NOTICES.md`.

## The right-click menu (optional)

`Add-RightClick-Menu.cmd` adds **"Run as Administrator (PS-Admin)"** to the
right-click menu for `.ps1` files.

- Writes **only** to `HKCU:\Software\Classes\...` — your user, no admin rights.
- On Windows 11 it may appear under **"Show more options"**.
- `Remove-RightClick-Menu.cmd` removes it completely.
- To see what it would write without writing it:
  `Install-ContextMenu.ps1 -WhatIf`

## Files

| file | what it is |
|---|---|
| `PS-Admin.cmd` | the launcher — drag a `.ps1` onto it, or double-click it |
| `PSAdmin.ps1` | the engine |
| `Add-RightClick-Menu.cmd` / `Remove-RightClick-Menu.cmd` | optional context menu |
| `Install-ContextMenu.ps1` / `Uninstall-ContextMenu.ps1` | what those call |
| `RUN-TEST.cmd` | proves the gate and the guards. Elevates nothing. |
| `THIRD-PARTY-NOTICES.md` | the sudo donor and its MIT licence |
| `donor-parts/` | the original donor files |

## Command line

```powershell
PSAdmin.ps1 -Script C:\path\to\thing.ps1
PSAdmin.ps1 -Script x.ps1 -Force                 # no confirmation pause
PSAdmin.ps1 -Script x.ps1 -Arguments '-Mode quick'
PSAdmin.ps1 -Task selftest
```

Exit codes: `0` ran or cancelled cleanly, `1` elevation declined or failed,
`2` the file was rejected.

## Verified

On Windows, via `RUN-TEST.cmd`: all three scripts parse; a `.ps1` with a space
in its name is accepted; `.cmd`, folders and missing files are refused; risky
cmdlets are flagged; single-quote escaping is correct; rejecting a non-`.ps1`
returns exit code 2; and `Install-ContextMenu.ps1 -WhatIf` writes nothing
(confirmed by checking the registry key afterwards).
